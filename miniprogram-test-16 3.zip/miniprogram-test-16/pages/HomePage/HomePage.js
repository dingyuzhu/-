// pages/HomePage.js

//获取应用实例
const app = getApp();
//下面这三个函数，就是初始化状态的。
function sort_display() {
  return ['sort_hide', 'sort_hide'];
}
function item_nav_set_list_light() {
  return ['', ''];
}
function item_nav_set_list_content_light() {
  return [
    ['', '', '', ''],
    ['', '']
  ];
}


var inputVal = '';//一开始输入框里的默认值为空
var msgList = [];
var windowWidth = wx.getSystemInfoSync().windowWidth; //窗口宽度变量
var windowHeight = wx.getSystemInfoSync().windowHeight;//窗口高度变量
var keyHeight = 0; //键盘高度


//初始化数据
function initData(that) {
  console.log('这个that是?：', that);  //that页面上所有声明的参数对象
  inputVal = '';

  msgList = [
    {
      speaker: 'server',
      contentType: 'text',
      content: '主人您好,我是你的智能金融助手小乐瑞，下面的问题我都可以帮你解决哦～'
    },
    {
      speaker: 'server',
      contentType: 'text',
      content: '基金详情咨询、基金小课堂等等，欢迎咨询！'
    },
    {
      speaker: 'customer',
      contentType: 'text',
      content: '你好,小瑞，我想咨询一下乐瑞宏观配置3号的最近走势'
    }
  ];

  that.setData({
    msgList,
    inputVal
  })
}


Page({
  data: {
    //这里是存储数据的地方，把改变过的东西放在这里。
    //主菜单高亮
    item_nav_set_list_light: item_nav_set_list_light(),
    //储存子菜单显示与否
    sort_status: sort_display(),
    //    子菜单高亮
    item_nav_set_list_content_light: item_nav_set_list_content_light(),

    //将要用来渲染的数据：
    array:[
      { fundName: "乐瑞宏观配置1号", fundCode: "001300", fundValue: "1.3722",fundTrend:"29.73%",fundDate:"2019.09.09"},
      { fundName: "乐瑞宏观配置2号", fundCode: "001301", fundValue: "1.0490", fundTrend: "13.04%", fundDate: "2019.09.09"},
      { fundName: "乐瑞宏观配置3号", fundCode: "001302", fundValue: "1.1831", fundTrend: "-12.92%", fundDate:"2019.09.09"},
      { fundName: "乐瑞宏观配置4号", fundCode: "001303", fundValue: "1.2990", fundTrend: "-14.06%", fundDate: "2019.09.09"},
      { fundName: "乐瑞宏观配置5号", fundCode: "001300", fundValue: "1.3722", fundTrend: "29.73%", fundDate: "2019.09.09"},
      
    ],
    //接收输入框的内容
    search_value:"",

    //标签页起始状态的index，0表示乐瑞产品,1表云课堂,so on....
    active:0,

    //云课堂部分的视频轮播资源图
    imgUrls: [
      '../../img/vdSwitch1.jpg',
      '../../img/vdSwitch2.jpg',
      '../../img/vdSwitch3.jpg',
      '../../img/vdSwitch4.png',
      '../../img/vdSwitch5.png',
    ],

    //视频的加载信息
    video:[
      { describe: "本期课堂的主讲内容是.....", title: "乐瑞基金小课堂1", videoURL:"../../img/vdSwitch5.png"},
      { describe: "本期课堂的主讲内容是.....", title: "乐瑞基金小课堂2", videoURL: "../../img/vdSwitch4.png"},
      { describe: "本期课堂的主讲内容是.....", title: "乐瑞基金小课堂3", videoURL: "../../img/vdSwitch3.jpg" },
      { describe: "本期课堂的主讲内容是.....", title: "乐瑞基金小课堂4", videoURL: "../../img/vdSwitch2.jpg" },
      { describe: "本期课堂的主讲内容是.....", title: "乐瑞基金小课堂5", videoURL: "../../img/vdSwitch1.jpg" }
    ],


    //聊天小助手
    scrollHeight: '100vh',//可滑动框的高度
    inputBottom: 0,//距离底部的距离
  },

 
  onLoad: function (options) {
    initData(this);
    console.log('这个this又是?', this);  //和上面的that一模一样，表示声明有值的各种参数的信息
    this.setData({
      cusHeadIcon: app.globalData.userInfo.avatarUrl,//获取用户的微信头像
      cusName: app.globalData.userInfo.nickName,//获取用户名
    })
  },

  //点击panel进入基金详情页面
  //https://www.cnblogs.com/e0yu/p/8488285.html
    panelClick:function(event){
      console.log('你点击了panel,即将进入每支基金的详情页面');
      wx.navigateTo({
        url: '../fundDetail/fundDetail',
      });
    },

  //搜索事件:根据基金名称或基金代码索引
    onSearch:function(value){
      console.log(value);
      this.setData({
        search_value:value.detail
      });
      console.log('这是你刚刚在搜索框内输入的内容:', value.detail);
      var that = this;
      var search_value = that.data.search_value;
      console.log(search_value);
      wx.request({
        url: '',
        data:{
          name:that.data.search_value  //通过name获取输入框中要求的data
        },
        method:"get",
        header:{
          'content-type': 'application/json'
        },
        success:function(res){

        }
      })

    },
  //取消搜索事件
    onCancel:function(){

    },


//点击标签切换底下内容，与data中的active相关
  onChange(event) {
    wx.showToast({
      title: `切换到标签 ${event.detail.index + 1}`,
      icon: 'none'
    });
  },

  //点击观看视频，导航到视频页面
    watchVideo:function(event){
      console.log('你点击了panel，并试图观看视频');
    },
  //点击观看ppt，导航到ppt详情页面
    watchppt: function (event) {
    console.log('你点击了panel，并试图观看ppt');
  },

  //获得焦点事件，bindfocus=focus
  focus: function (e) {
    console.log('这获取焦点事件的e是？', e);
    keyHeight = e.detail.height; //点击输入框，当底部弹出键盘时，获取keyHeight=输入盘高度
    this.setData({
      scrollHeight: (windowHeight - keyHeight) + 'px', //此时聊天框的高度
    });
    this.setData({
      toView: 'msg-' + (msgList.length),
      //信息的条数-1,scroll-view滑动范围就到id=msgList.length-1的view为止,
      inputBottom: keyHeight + 'px',
      //此刻低端输入框高度随键盘上升为keyHeight
    })
  },


  //失去焦点（键盘消失）事件：bindblur:blur
  blur: function (e) {
    this.setData({
      scrollHeight: '100vh',//当键盘消失，scroll-view范围重新回到一开始的100vh
      inputBottom: 0,//输入框再次跌入底部，高度为0
    })
    this.setData({
      toview: 'msg-' + (msgList.length)
      //scroll-view会触底id=msgList.length-1的新view
    })
  },


  //点击发送消息事件,也就是点击回车或者发送
  sendClick: function (e) {
    console.log('回车发送消息的e是？', e);
    msgList.push({
      speaker: 'customer',
      contentType: 'text',
      content: e.detail.value,//往msgList对话列表中加元素
    })
    inputVal = '';//回车一次清空输入框一次
    this.setData({
      msgList,  //新的对话列表
      inputVal //新的输入框
    })
  },

  //点击发送消息的事件
  sendbtn: function (e) {
    console.log('点击发送按钮后的事件e是？', e);
    msgList.push({
      speaker: 'customer',
      contentType: 'text',
      content: e.detail.x,//往msgList对话列表中加元素
    })
    inputVal = '';//回车一次清空输入框一次
    this.setData({
      msgList,  //新的对话列表
      inputVal //新的输入框
    })
  }


})