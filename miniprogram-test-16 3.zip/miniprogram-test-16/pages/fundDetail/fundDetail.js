// pages/fundDetail/fundDetail.js
import F2 from '@antv/wx-f2';
let chart = null;
let chart1 = null;
//获取应用实例
const app = getApp();

//在Page外面函数都这么声明？
function initChart(canvas, width, height, F2) {
  const data = [{
    time: '2016-08-08 00:00:00',
    value: 10,
    type: '预期收益率'
  }, {
    time: '2016-08-08 00:10:00',
    value: 22,
    type: '预期收益率'
  }, {
    time: '2016-08-08 00:30:00',
    value: 16,
    type: '预期收益率'
  }, {
    time: '2016-08-09 00:35:00',
    value: 26,
    type: '预期收益率'
  }, {
    time: '2016-08-09 01:00:00',
    value: 12,
    type: '预期收益率'
  }, {
    time: '2016-08-09 01:20:00',
    value: 26,
    type: '预期收益率'
  }, {
    time: '2016-08-10 01:40:00',
    value: 18,
    type: '预期收益率'
  }, {
    time: '2016-08-10 02:00:00',
    value: 26,
    type: '预期收益率'
  }, {
    time: '2016-08-10 02:20:00',
    value: 12,
    type: '预期收益率'
  }, {
    time: '2016-08-08 00:00:00',
    value: 4,
    type: '实际收益率'
  }, {
    time: '2016-08-08 00:10:00',
    value: 3,
    type: '实际收益率'
  }, {
    time: '2016-08-08 00:30:00',
    value: 6,
    type: '实际收益率'
  }, {
    time: '2016-08-09 00:35:00',
    value: -12,
    type: '实际收益率'
  }, {
    time: '2016-08-09 01:00:00',
    value: 1,
    type: '实际收益率'
  }, {
    time: '2016-08-09 01:20:00',
    value: 9,
    type: '实际收益率'
  }, {
    time: '2016-08-10 01:40:00',
    value: 13,
    type: '实际收益率'
  }, {
    time: '2016-08-10 02:00:00',
    value: -3,
    type: '实际收益率'
  }, {
    time: '2016-08-10 02:20:00',
    value: 11,
    type: '实际收益率'
  }];

  //画布的基本参数
  chart = new F2.Chart({
    el: canvas,
    width,
    height,
    animate: true
  });


  //加载作图的数据和对属性的一些配置
  chart.source(data, {
    //配置time属性
    time: {
      type: 'timeCat', //声明time属性为时间类型
      tickCount: 3,//坐标轴上刻度点的个数
      range: [0, 1], //输出数据的范围，数值类型的默认值为 [0, 1]
      mask: 'hh:mm', //数据的格式化格式 默认：'YYYY-MM-DD'。
    },
    //配置value属性
    value: {
      tickCount: 3,
      formatter: function formatter(ivalue) {
        return ivalue + '%'
      }
    }
  });

  //设置time在坐标轴的表现
  chart.axis('time', {
    line: null, //坐标轴线,x轴
    //刻度文本
    label: function label(text, index, total) {
      var textCfg = {};
      if (index === 0) {
        textCfg.textAlign = 'left';
      } else if (index === total - 1) {
        textCfg.textAlign = 'right';
      }
      return textCfg;
    }
  });

  chart.axis('tem', {
    //设置网格线
    grid: function grid(text) {
      if (text === "0%") {
        return {
          lineDash: null,
          lineWidth: 1
        };
      }
    }
  });

  //图例说明
  chart.legend({
    position: 'top',//显示在图上方
    offsetY: -5
  });

  //线，点按照 x 轴连接成一条线，构成线图。
  //position('a*b')分别将属性a,b映射到x,y轴
  //将 type 属性的数据值映射至制定的颜色来区分不同的类型。
  //按type的不同绘制不同shape的线
  chart.line().position('time*value').color('type', ['#5174FF','red']).shape('type', function (type) {
    if (type == '预期收益率') {
      return 'line'; //circle
    }
    if (type == '实际收益率') {
      return 'dash'; //rect
    }
  });

  chart.render();
}


Page({

  data: {
    //切换标签
    active: 0,
    //历史业绩部分的渲染
    history1:[
      {duration:"近一周",fundTrend:"+8.41%",rank:"2/3180"},
      {duration: "近一月", fundTrend: "+13.52%", rank: "2/3153" },
      {duration: "近三月", fundTrend: "+31.91%", rank: "2/3047" },
      {duration: "近六月", fundTrend: "+29.39%", rank: "86/2906" },
      ],
    //历史净值部分的渲染
    history2: [
      { date: "2019.09.09", singleValue: "1.8308", accumulateValue: "1.8308", dailyTrend:"+1.9%"},
      { date: "2019.09.09", singleValue: "1.8308", accumulateValue: "1.8308", dailyTrend: "+1.9%" },
      { date: "2019.09.09", singleValue: "1.8308", accumulateValue: "1.8308", dailyTrend: "+1.9%" },
      { date: "2019.09.09", singleValue: "1.8308", accumulateValue: "1.8308", dailyTrend: "+1.9%" },
    ],

    //步骤条
    steps: [
      {
        desc: '买入提交'
      },
      {
        desc: '确认份额'
      },
      {
        desc: '查看盈亏'
      }
    ],

    //业绩走势
    opts: {
      onInit: initChart
    },
    opts: {
      onInit: initChart
    }
  
  },

  onReady() {

  },

  //标签之间切换时的函数
  onChange(event) {
    wx.showToast({
      title: `切换到标签 ${event.detail.index + 1}`,
      icon: 'none'
    });
  },

 onLoad:function(options){
    //动态设置微信顶部导航栏的内容😄,使用API
    wx.setNavigationBarTitle({
     title:  '乐瑞宏观配置1号'
   })
 },


})